//
//  ProductsTableViewCell.swift
//  [Swift]ViperArchitecture
//
//  Created by Ge Ding on 12/6/23.
//

import UIKit

class ProductsTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLB: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
