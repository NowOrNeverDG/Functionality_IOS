//
//  Router.swift
//  [Swift]ViperArchitecture
//
//  Created by Ge Ding on 12/6/23.
//

import Foundation
import UIKit

class ProductsRouter: PresenterToRouterProtocol {
    @discardableResult
    static func createModule() -> ProductsViewController {
        let view = mainstoryboard.instantiateViewController(withIdentifier: "ProductsViewController") as! ProductsViewController

        let presenter: ViewToPresenterProtocol & InteractorToPresenterProtocol = ProductPresenter()
        let interactor: PresenterToInteractorProtocol = ProductInteractor()
        let router:PresenterToRouterProtocol = ProductsRouter()
        
        view.presenter = presenter
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        presenter.interactor?.presenter = presenter
        
        return view
    }
    
    static var mainstoryboard: UIStoryboard{
        return UIStoryboard(name:"Main",bundle: Bundle.main)
    }
    
    
}
