//
//  ViewController.swift
//  [Swift]ViperArchitecture
//
//  Created by Ge Ding on 12/5/23.
//

import UIKit

class ProductsViewController: UIViewController {
    var presenter: ViewToPresenterProtocol?
    
    var productsArr: [Product] = []
    @IBOutlet weak var productsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.startFetchingProducts()
        
    }
}

extension ProductsViewController: PresenterToViewProtocol {
    func showProducts(_ products: [Product]) {
        
        DispatchQueue.main.async {
            self.productsArr = products
            self.productsTableView.reloadData()
        }
    }
    
    func showError() {
    }
    
    func showLoading() {
    }
}

extension ProductsViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("numberofSection:\(productsArr.count)")
        return productsArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cellForRowAt")
        let cell = UITableViewCell()
        cell.textLabel?.text = productsArr[indexPath.row].title
        return cell
    }
    
}
